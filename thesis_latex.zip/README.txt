################################################################################
#
# README for writing a thesis in LaTeX
#
################################################################################

Use this template to write a bachelor or master's thesis or a dissertation.


For general help about using the templates and for help with LaTeX, please consult 
the top-level README.txt file.

 
